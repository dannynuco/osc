#!/bin/bash
source ./setenv.sh
./nucog	--verbosity=4
