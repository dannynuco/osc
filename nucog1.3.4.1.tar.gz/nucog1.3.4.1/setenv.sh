#!/bin/bash
export LD_LIBRARY_PATH=./lib
export PATH=$PATH:./:./tools/

