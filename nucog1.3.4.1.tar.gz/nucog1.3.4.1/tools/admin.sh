#!/bin/bash
source ./setenv.sh
./nucog attach
